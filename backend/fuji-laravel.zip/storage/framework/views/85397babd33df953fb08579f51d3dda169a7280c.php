<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>お問い合わせ内容一覧</title>
  <style>
    th,td {
    border: solid 1px;          /* 枠線指定 */
    }
    
    table {
        border-collapse:  collapse; /* セルの線を重ねる */
        width:  100%;               /* 幅指定 */
    }
    
    th {
        width:  100px;              /* 幅指定 */
        text-align: center;           /* 文字の揃え位置指定 */
    }
    
    td {
        text-align:  center;        /* 文字の揃え位置指定 */
    }
  </style>
</head>

<body>
  <h1>お問い合わせ一覧</h1>
  <table>
    <tr>
      <th>id</th>
      <th>名前</th>
      <th>メールアドレス</th>
      <th>お問い合わせ内容</th>
      <th>Facebookの名前</th>
      <th>ユーザーID</th>
      <th>詳細・説明</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($contact->id); ?></td>
          <td><?php echo e($contact->name); ?></td>
          <td><?php echo e($contact->email); ?></td>
          <td><?php echo e($contact->item); ?></td>
          <td><?php echo e($contact->facebook_name); ?></td>
          <td><?php echo e($contact->user_uid); ?></td>
          <td><?php echo e($contact->detail); ?></td>
        </tr>
        <button>対応する</button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</body>

</html><?php /**PATH /work/laravel/resources/views/contact.blade.php ENDPATH**/ ?>