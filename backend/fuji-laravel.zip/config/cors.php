<?php
return [
 'paths' => ['*'],
 'allowed_methods' => ['*'],
 'allowed_origins' => ['*'],
 'allowed_origins_patterns' => [],
 'allowed_headers' => ['*'],
 'exposed_headers' => false,
 'max_age' => false,
 'supports_credentials' => false,
];